package com.example.tugas_kinan

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
